#include "buildModel.h"

/**

TODO:

Construye un modelo de PGUPV con una representaci�n de mapa de alturas con la malla dada.
La malla de entrada es de dimensi�n 2, y tiene un atributo de tipo float.
Si las coordenadas de una muestra son (x, y), y su atributo es h, el v�rtice que lo representar�
estar� en:

glm::vec3(x, h, -y)

Si las celdas son tri�ngulos (es decir, la funci�n getCellSamples devuelve 3), se deber� dibujar un tri�ngulo
de OpenGL por celda. Si las celdas son cuadril�teros (es decir, la funci�n getCellSamples devuelve 4), se deber�n dibujar 2
tri�ngulos por celda.

Tambi�n deber�s establecer el color de cada v�rtice. Dise�a tu propio mapa de colores, teniendo en cuenta el rango de
valores de las muestras de entrada.

*/

std::shared_ptr<PGUPV::Model> vdc::build2DHeightMapFromGrid(const vdc::Grid<glm::vec2, float>& g) {
	auto model = std::make_shared<Model>();

	glm::vec2 min, max;
	min = max = g.getSamplePosition(0);
	std::vector<glm::vec3> coordinates;
	for (size_t i = 0; i < g.numSamples(); i++) {
		auto pi = g.getSamplePosition(i);
		min = glm::min(min, pi);
		max = glm::max(max, pi);
	}

	// Construir los v�rtices del mapa de alturas
	//std::vector<glm::vec3> coordinates;
	
	for (size_t i = 0; i < g.numCells(); i++) {
		size_t array[4];
		auto cell_samples = g.getCellSamples(i, array);
		if (cell_samples == 3) {
			// Construir un tri�ngulo
			coordinates.push_back(glm::vec3(g.getSamplePosition(array[0]).x, g.getSampleValue(array[0]), -g.getSamplePosition(array[0]).y));
			coordinates.push_back(glm::vec3(g.getSamplePosition(array[1]).x, g.getSampleValue(array[1]), -g.getSamplePosition(array[1]).y));
			coordinates.push_back(glm::vec3(g.getSamplePosition(array[2]).x, g.getSampleValue(array[2]), -g.getSamplePosition(array[2]).y));
		}
		else if (cell_samples == 4) {
			// Construir dos tri�ngulos
			coordinates.push_back(glm::vec3(g.getSamplePosition(array[0]).x, g.getSampleValue(array[0]), -g.getSamplePosition(array[0]).y));
			coordinates.push_back(glm::vec3(g.getSamplePosition(array[1]).x, g.getSampleValue(array[1]), -g.getSamplePosition(array[1]).y));
			coordinates.push_back(glm::vec3(g.getSamplePosition(array[2]).x, g.getSampleValue(array[2]), -g.getSamplePosition(array[2]).y));

			coordinates.push_back(glm::vec3(g.getSamplePosition(array[0]).x, g.getSampleValue(array[0]), -g.getSamplePosition(array[0]).y));
			coordinates.push_back(glm::vec3(g.getSamplePosition(array[2]).x, g.getSampleValue(array[2]), -g.getSamplePosition(array[2]).y));
			coordinates.push_back(glm::vec3(g.getSamplePosition(array[3]).x, g.getSampleValue(array[3]), -g.getSamplePosition(array[3]).y));
		}
	}
	
	// Construir los tri�ngulos
	std::vector<unsigned int> indices;
	
	for (size_t i = 0; i < g.numCells(); i++) {
		size_t array[4];
		auto cell_samples = g.getCellSamples(i,array);
		if (cell_samples == 3) {
			// Tri�ngulo
			indices.push_back(3*i);
			indices.push_back(3*i+1);
			indices.push_back(3*i+2);
		}
		else if (cell_samples == 4) {
			// Dos tri�ngulos
			indices.push_back(i * 6);
			indices.push_back(i * 6 +1);
			indices.push_back(i * 6 +2);
			indices.push_back(i * 6);
			indices.push_back(i * 6 +4);
			indices.push_back(i * 6 +5);
		}
	}
	
	

	std::vector<glm::vec4> colors;
	// Definir el gradiente de color
	glm::vec4 lowColor = glm::vec4(0.0f, 0.0f, 0.5f, 1.0f);
	glm::vec4 highColor = glm::vec4(1.0f, 0.0f, 0.0f, 1.0f);

	// Encontrar los valores m�nimo y m�ximo de las muestras
	float minValue = std::numeric_limits<float>::max();
	float maxValue = -std::numeric_limits<float>::max();

	for (size_t i = 0; i < g.numSamples(); i++) {
		float value = g.getSampleValue(i);
		if (value < minValue) {
			minValue = value;
		}
		if (value > maxValue) {
			maxValue = value;
		}
	}

	// Asignar un color a cada v�rtice seg�n su valor
	for (size_t i = 0; i < coordinates.size(); i++) {
		float value = coordinates[i].y;
		glm::vec4 color = glm::mix(lowColor, highColor, (value - minValue) / (maxValue - minValue));
		colors.push_back(color);
	}


	// Malla
	auto base = std::make_shared<Mesh>();
	base->addVertices(coordinates);
	base->addIndices(indices);
	base->addColors(colors);

	base->addDrawCommand(new DrawElements(GL_TRIANGLES, static_cast<GLsizei>(indices.size()), GL_UNSIGNED_INT, 0));
	model->addMesh(base);
	return model;
	}

glm::vec3 getColor(float value) {
	float r = std::max(0.0f, std::min(1.0f, 1.0f - value));
	float g = std::max(0.0f, std::min(1.0f, value));
	float b = 0.0f;
	return glm::vec3(r, g, b);
}


float secretFunc(float, float);


/**
Dada una malla, asigna a cada muestra su valor (dada su posici�n)
*/
void fillSamples(vdc::Grid<glm::vec2, float>& grid) {
	for (size_t i = 0; i < grid.numSamples(); i++) {
		auto v = grid.getSamplePosition(i);
		grid.setSampleValue(i, secretFunc(v.x, v.y));
	}
}


// Malla uniforme
std::unique_ptr<vdc::UniformGrid<glm::vec2, float>> vdc::buildUniformGrid(const int horizontalVtcs, const int verticalVtcs, const glm::vec2& min, const glm::vec2& max)
{
	auto uniformGrid = std::unique_ptr<vdc::UniformGrid<glm::vec2, float>>(new vdc::UniformGrid<glm::vec2, float>(min, max, { horizontalVtcs, verticalVtcs }));
	fillSamples(*uniformGrid);
	return uniformGrid;
}


/**
TODO:

Cambia en los siguientes m�todos la forma de construir las mallas para que, con el mismo n�mero de muestras
que la malla uniforme, se obtenga una mejor aproximaci�n a la funci�n original.
La versi�n que se entrega define todas las mallas iguales (las muestras est�n equiespaciadas)
*/

// Malla rectil�nea
std::unique_ptr<vdc::RectilinearGrid<glm::vec2, float>>  vdc::buildRectilinearGrid(const int horizontalVtcs, const int verticalVtcs, const glm::vec2& min, const glm::vec2& max) {
	std::vector<float> posX;
	float aux;
	for (int i = 0; i < horizontalVtcs; i++) {
		posX.push_back((max.x - min.x) * i / (horizontalVtcs - 1) + min.x);
	}
	for (int i = 1; i < horizontalVtcs - 1; i++) {
		if (i < 2) {
			posX[i] = posX[i - 1] + 1.2;
		}else if (15 < i < 40) {
			posX[i] = posX[i - 1] + 0.07;
		}

	}
	
	
	std::vector<float> posY;
	for (int i = 0; i < verticalVtcs; i++) {
		posY.push_back((max.y - min.y) * i / (verticalVtcs - 1) + min.y);
	}

	for (int i = 1; i < verticalVtcs - 1; i++) {
		if ( 3 < i < 25) {
			posY[i] = posY[i - 1] + 0.05;
		}
		else if ( 30 < i ) {
			posY[i] = posY[i - 1] + 1.2;
		}

	}
	auto rectilinearGrid = std::unique_ptr<vdc::RectilinearGrid<glm::vec2, float>>(new vdc::RectilinearGrid<glm::vec2, float>(posX, posY));
	fillSamples(*rectilinearGrid);
	return rectilinearGrid;
	
}

// Malla estructurada
std::unique_ptr<vdc::StructuredGrid<glm::vec2, float>> vdc::buildStructuredGrid(const int horizontalVtcs, const int verticalVtcs, const glm::vec2& min, const glm::vec2& max) {
	auto structuredGrid = std::unique_ptr < vdc::StructuredGrid<glm::vec2, float>>(new vdc::StructuredGrid<glm::vec2, float>({horizontalVtcs, verticalVtcs}));
	size_t i = 0;
	auto offset = (max - min) / glm::vec2{ horizontalVtcs - 1, verticalVtcs - 1 };
	for (int y = 0; y < verticalVtcs; y++) {
		for (int x = 0; x < horizontalVtcs; x++) {
			glm::vec2 pos = min + glm::vec2{ x, y } *offset;
			structuredGrid->setSamplePosition(i++, pos);
		}
	}
	fillSamples(*structuredGrid);
	return structuredGrid;
	/*auto structuredGrid = std::unique_ptr<vdc::StructuredGrid<glm::vec2, float>>(new vdc::StructuredGrid<glm::vec2, float>({horizontalVtcs, verticalVtcs}));
	size_t i = 0;
	for (int y = 0; y < verticalVtcs; y++) {
		for (int x = 0; x < horizontalVtcs; x++) {
			float u = (float)x / (float)(horizontalVtcs - 1);
			float v = (float)y / (float)(verticalVtcs - 1);
			glm::vec2 pos = (1.0f - u) * min + u * max + (1.0f - v) * min + v * max;
			structuredGrid->setSamplePosition(i++, pos);
		}
	}
	fillSamples(*structuredGrid);
	return structuredGrid;*/

}

// Malla no estructurada
std::unique_ptr<vdc::UnstructuredTriangleGrid<glm::vec2, float>> vdc::buildUnstructuredGrid(const int horizontalVtcs, const int verticalVtcs, const glm::vec2& min, const glm::vec2& max) {
	auto unstructuredGrid = std::unique_ptr < vdc::UnstructuredTriangleGrid<glm::vec2, float>>(
		new vdc::UnstructuredTriangleGrid<glm::vec2, float>(
			{ static_cast<size_t>(horizontalVtcs) * verticalVtcs, 2ULL * (horizontalVtcs - 1) * (verticalVtcs - 1) }));
	size_t i = 0;

	auto offset = (max - min) / glm::vec2{ horizontalVtcs - 1, verticalVtcs - 1 };
	for (int y = 0; y < verticalVtcs; y++) {
		for (int x = 0; x < horizontalVtcs; x++) {
			glm::vec2 pos = min + glm::vec2{ x, y } *offset;
			unstructuredGrid->setSamplePosition(i++, pos);
		}
	}

	fillSamples(*unstructuredGrid);
	assert(i == horizontalVtcs * verticalVtcs);

	i = 0;
	for (int cellY = 0; cellY < verticalVtcs - 1; cellY++) {
		for (int cellX = 0; cellX < horizontalVtcs - 1; cellX++) {
			size_t v[3];
			size_t firstV = cellX + horizontalVtcs * cellY;
			v[0] = firstV;
			v[1] = firstV + 1;
			v[2] = v[1] + horizontalVtcs;
			unstructuredGrid->setCell(i++, v);

			v[0] = firstV;
			v[1] = firstV + 1 + horizontalVtcs;
			v[2] = v[1] - 1;
			unstructuredGrid->setCell(i++, v);
		}
	}
	assert(i == (horizontalVtcs - 1) * (verticalVtcs - 1) * 2);
	return unstructuredGrid;

}

/**
TODO:

Tendr�s que implementar el algoritmo de derivaci�n visto en clase.

*/

std::shared_ptr<vdc::StructuredGrid<glm::vec2, glm::vec2>> vdc::derivative(const vdc::UniformGrid<glm::vec2, float>& g) {
	/*std::vector<int> dims{g.getNumSamplesPerDimension(0), g.getNumSamplesPerDimension(1)};
	auto result = std::make_shared<vdc::StructuredGrid<glm::vec2, glm::vec2>>(dims);
	glm::vec2 derivada;
	for (size_t i = 0; i < g.numSamples(); i++) {
		size_t array[4];
		auto cell_samples = g.getCellSamples(i, array);
		derivada = (1-s);
		std::cout << "muesta f0:" << array[0] << "\n";
		std::cout << "muesta f0: (" << g.getSamplePosition(array[0]).x <<"," << g.getSamplePosition(array[0]).y<< ")\n";
		result->setSamplePosition(i, g.getSamplePosition(i));
		result->setSampleValue(i, glm::vec2(1, 1));
	}
	return result;*/
	std::vector<int> dims{ g.getNumSamplesPerDimension(0), g.getNumSamplesPerDimension(1) };
	auto result = std::make_shared<vdc::StructuredGrid<glm::vec2, glm::vec2>>(dims);
	//Clculamos los delta que son el tama�o de la celda
	float delta1 = (g.getMaxCoord().x - g.getMinCoord().x) / (g.getNumSamplesPerDimension(0) - 1);
	float delta2 = (g.getMaxCoord().y - g.getMinCoord().y) / (g.getNumSamplesPerDimension(1) - 1);

	for (size_t i = 0; i < g.numSamples(); i++) {
		//calculamos las coordenadas de la celda actual normalizadas enre 0 y 1
		int columna = i % g.getNumSamplesPerDimension(0);
		int fila = i / g.getNumSamplesPerDimension(0);
		float s = static_cast<float>(columna) / (g.getNumSamplesPerDimension(0) - 1);
		float r = static_cast<float>(fila) / (g.getNumSamplesPerDimension(1) - 1);
		//calculamos los valores de las muestras
		int pos1 = i;
		int pos2 = (i + 1) < g.numSamples() ? i + 1 : i;
		int pos3 = (i + g.getNumSamplesPerDimension(0) + 1) < g.numSamples() ? i + g.getNumSamplesPerDimension(0) + 1 : i;
		int pos4 = (i + g.getNumSamplesPerDimension(0)) < g.numSamples() ? i + g.getNumSamplesPerDimension(0): i;
		float f1 = g.getSampleValue(pos1);
		float f2 = g.getSampleValue(pos2);
		float f3 = g.getSampleValue(pos3);
		float f4 = g.getSampleValue(pos4);
		//Aplicamos la formula de la derivada vista en clase
		glm::vec2 derivative(((1 - s) * (f2 - f1) / delta1 + s * (f3 - f4) / delta1), (1 - r) * (f4 - f1) / delta2 + r * (f3 - f2) / delta2);
		result->setSamplePosition(i, g.getSamplePosition(i));
		result->setSampleValue(i, derivative);
	}
	return result;
	
}
