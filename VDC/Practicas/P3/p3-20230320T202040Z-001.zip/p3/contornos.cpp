#include <iostream>
#include "contornos.h"
#include <mesh.h>
#include <drawCommand.h>

using namespace PGUPV;

/**
Calcula el contorno en la malla para el valor indicado.
\param grid malla en la que se calcula el contorno
\param contourValue el valor por el que pasa la l�nea de contorno
\return un modelo PGUPV con los segmentos que componen la l�nea de contorno
*/
std::shared_ptr<Model> computeContourLine(const vdc::Grid<glm::vec2, float> &grid, float contourValue) {
    auto model = std::make_shared<PGUPV::Model>();

    // Recorremos todas las celdas de la malla
    std::vector<glm::vec2> intersections;
    for (size_t i = 0; i < grid.numCells(); i++) {
        size_t array[4];
        auto cell_samples = grid.getCellSamples(i, array);
        // Obtenemos los valores de los v�rtices de la celda
        auto v1 = grid.getSampleValue(array[0]);
        auto v2 = grid.getSampleValue(array[1]);
        auto v3 = grid.getSampleValue(array[2]);
        auto v4 = grid.getSampleValue(array[3]);
        auto p1 = grid.getSamplePosition(array[0]);
        auto p2 = grid.getSamplePosition(array[1]);
        auto p3 = grid.getSamplePosition(array[2]);
        auto p4 = grid.getSamplePosition(array[3]);


        // Comprobamos si la celda intersecta con el valor de la isol�nea

        if (v1 >= contourValue && v2 < contourValue) {
            auto q = (p1 * (v2-contourValue) + p2 * (contourValue-v1)) / (v2 - v1);
            intersections.push_back(q);
            
        }
        if (v2 >= contourValue && v3 < contourValue) {
            auto q = (p2 * (v3-contourValue) + p3 * (contourValue - v2)) / (v3 - v2);
            intersections.push_back(q);
        }
        if (v3 >= contourValue && v4 < contourValue) {
            auto q = (p3 * (v4 - contourValue) + p4 * (contourValue - v3)) / (v4 - v3);
            intersections.push_back(q);
        }
        if (v4 >= contourValue && v1 < contourValue) {
            auto q = (p4 * (v1 - contourValue) + p1 * (contourValue - v4)) / (v1 - v4);
            intersections.push_back(q);
        }

    }
    // Construir las lineas
    std::vector<unsigned int> indices;
    
    for (unsigned int i = 0; i < intersections.size(); i+=2) {
        indices.push_back(i);
        indices.push_back(i + 1);
    }

    
    /*for (unsigned int i = 0; i < intersections.size(); i++) {
        indices.push_back(i * 4);
        indices.push_back(i * 4 + 1);
        indices.push_back(i * 4 + 2);
        indices.push_back(i * 4 + 3);

    
    }*/

    // Si la celda intersecta con el valor de la isol�nea, a�adimos las intersecciones al modelo
    auto base = std::make_shared<Mesh>();
    if (intersections.size() > 0) {
        base->addVertices(intersections);
        base->addIndices(indices);
        base->addDrawCommand(new DrawElements(GL_POINTS, static_cast<GLsizei>(indices.size()), GL_UNSIGNED_INT, 0));
        model->addMesh(base);
    }

    return model;
}
