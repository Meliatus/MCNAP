﻿
#include <vector>
#include <glm/glm.hpp>
#include <glm/gtc/random.hpp>
#include <algorithm>

#include "colormap.h"

/*

Completa las funciones de este fichero.
Cada función devuelve un vector con los colores que componen cada tipo de mapa de color.

*/

/**
\return un mapa de color aleatorio (256 colores elegidos aleatoriamente)
*/
std::vector<glm::vec4> createRandomColorMap() {
  std::vector<glm::vec4> colormap;
  for (unsigned int i = 0; i < 256; i++) {
    colormap.push_back(glm::linearRand(glm::vec4(0.0f), glm::vec4(1.0f)));
  }
  return colormap;
}


/**
\return los colores de un mapa de niveles de gris
*/
std::vector<glm::vec4> createGrayscaleColorMap() {
  std::vector<glm::vec4> colormap;
  for (unsigned int i = 0; i < 256; i++) {
      colormap.push_back(glm::vec4(glm::vec3(i / 255.f), 1));
  }
  return colormap;
}

/**
\return los colores de un mapa arco iris
*/
std::vector<glm::vec4> createRainbowColorMap() {
  std::vector<glm::vec4> colormap;
  for (unsigned int i = 0; i < 256; i++) {
      float t = (float)i / 255.f;
      glm::vec4 color;
      if (t <= 0.25f) {
          color = glm::vec4(1, 4 * t, 0, 1);
      }
      else if (t <= 0.5f) {
          color = glm::vec4(1 - 4 * (t - 0.25f), 1, 0, 1);
      }
      else if (t <= 0.75f) {
          color = glm::vec4(0, 1, 4 * (t - 0.5f), 1);
      }
      else {
          color = glm::vec4(0, 1 - 4 * (t - 0.75f), 1, 1);
      }
      colormap.push_back(color);
  }
  return colormap;
}

/**
\return los colores de un mapa de dos matices
\param low el color asociado a los valores bajos
\param high el color asociado a los valores altos
*/

std::vector<glm::vec4> createTwoColorMap(const glm::vec4 &low, const glm::vec4 &high) {
  std::vector<glm::vec4> colormap;
  for (unsigned int i = 0; i < 256; i++) {
      float t = (float)i / 255.f;
      glm::vec4 color = glm::mix(low, high, t);
      colormap.push_back(color);
  }
  return colormap;
}

/**
\return los colores de un mapa de calor
*/
std::vector<glm::vec4> createHeatColorMap() {
  std::vector<glm::vec4> colormap;
  for (unsigned int i = 0; i < 256; i++) {
      float t = (float)i / 255.f;
      glm::vec4 color;
      if (t < 0.25f) {
          color = glm::vec4(0, 0, 4 * t, 1);
      }
      else if (t < 0.5f) {
          color = glm::vec4(0, 4 * (t - 0.25f), 1, 1);
      }
      else if (t < 0.75f) {
          color = glm::vec4(4 * (t - 0.5f), 1, 1 - 4 * (t - 0.5f), 1);
      }
      else {
          color = glm::vec4(1, 1 - 4 * (t - 0.75f), 0, 1);
      }
      colormap.push_back(color);
  }
  return colormap;
}

/**
\return los colores de un mapa divergente
\param low el color asociado al valor más bajo
\param mid el color asociado al valor medio
\param high el color asociado al valor más alto
*/
std::vector<glm::vec4> createDivergingColorMap(const glm::vec4 &low, const glm::vec4 &mid, const glm::vec4 &high) {
  std::vector<glm::vec4> colormap;
  // Calculamos la posición central del mapa de colores
  const float midPos = 0.5f;

  // Generamos los colores para la mitad inferior del mapa de colores
  for (unsigned int i = 0; i < 128; i++) {
      float t = static_cast<float>(i) / 127.f; // Normalizamos el valor de i entre 0 y 1
      glm::vec4 color = glm::mix(low, mid, t); // Interpolamos linealmente entre el color bajo y el medio
      colormap.push_back(color);
  }

  // Agregamos el color medio en la posición central del mapa de colores
  colormap.push_back(mid);

  // Generamos los colores para la mitad superior del mapa de colores
  for (unsigned int i = 0; i < 128; i++) {
      float t = static_cast<float>(i) / 127.f; // Normalizamos el valor de i entre 0 y 1
      glm::vec4 color = glm::mix(mid, high, t); // Interpolamos linealmente entre el color medio y el alto
      colormap.push_back(color);
  }
  return colormap;
}


/**
\return los colores de un mapa de color de cebra
\param one un color
\param two otro color (para funcionar ambos colores deben tener una luminancia muy distinta)
*/

std::vector<glm::vec4> createZebraColorMap(const glm::vec4 &one, const glm::vec4 &two) {
  std::vector<glm::vec4> colormap;
  // Definimos la cantidad de rayas que queremos en el mapa de colores
  const unsigned int numStripes = 256;

  // Alternamos los dos colores en cada par de rayas
  for (unsigned int i = 0; i < numStripes; i++) {
      if (i % 2 == 0) {
          colormap.push_back(one);
      }
      else {
          colormap.push_back(two);
      }
  }
  return colormap;
}
