
#include <stdlib.h>
#include <iostream>
#include "tbb/parallel_reduce.h"
#include "tbb/blocked_range.h"
using namespace tbb;
using namespace std;

double Foo( double f ) { 
  unsigned int u = (unsigned int) f;
  double a = (double) rand_r(&u) / RAND_MAX;
  a = a*a; 
  return a;
}

class SumFoo {
  double* my_a;
  public:
    double sum;
    void operator()( const blocked_range<size_t>& r ) {
      double *a = my_a;
      for( size_t i=r.begin(); i!=r.end(); ++i )
        sum += Foo(a[i]);
    }
  
  SumFoo( SumFoo& x, split ) : my_a(x.my_a), sum(0) {}
  void join( const SumFoo& y ) { sum+=y.sum; }
  SumFoo( double a[] ) : my_a(a), sum(0) {}
};

double ParallelSumFoo( double a[], size_t n ) {
  SumFoo sf(a);
  parallel_reduce( blocked_range<size_t>(0,n), sf );
  return sf.sum;
}

double SerialSumFoo( double a[], size_t n ) { 
  double sum = 0;
  for( size_t i=0; i!=n; ++i ) 
    sum += Foo(a[i]);
  return sum;
}

int main( )  {

  long int n = 1000000;
  double *A = (double *) malloc( n*sizeof(double) );
  for( size_t i=0; i<n; ++i ) A[i] = i;
  //double suma = SerialSumFoo( A, n );
  double suma = ParallelSumFoo( A, n );
  cout << "Suma = " << suma << endl;

}


