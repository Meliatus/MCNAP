
#include <stdlib.h>
#include <cfloat>
#include <iostream>
#include "tbb/parallel_reduce.h"
#include "tbb/blocked_range.h"
using namespace tbb;
using namespace std;

double Foo( double f ) { 
  double a = f*f; 
  return a;
}


class MinIndexFoo {


  double* my_a;
  public:
    double my_value_of_min; 
    long my_index_of_min; 

    void operator()( const blocked_range<size_t>& r ) {
      double *a = my_a;
      for( size_t i=r.begin(); i!=r.end(); ++i ) {
        double value = Foo(a[i]); 
        if( value < my_value_of_min ) {
          my_value_of_min = value; 
          my_index_of_min = i;
        }
      } 
    }
  
  MinIndexFoo( MinIndexFoo& x, split ) : 
    my_a(x.my_a), 
    my_value_of_min(RAND_MAX), 
    my_index_of_min(-1) {}
  void join( const MinIndexFoo& y ) { 
    if( y.my_value_of_min<my_value_of_min ){
      my_value_of_min = y.my_value_of_min;
      my_index_of_min = y.my_index_of_min;

    }
  }
  MinIndexFoo( double a[] ) : 
  my_a(a), 
  my_value_of_min(RAND_MAX), 
  my_index_of_min(-1){}
};

double ParallelMinIndexFoo( double a[], size_t n ) {
  MinIndexFoo sf(a);
  parallel_reduce( blocked_range<size_t>(0,n), sf );
  return sf.my_index_of_min;
}

long SerialMinIndexFoo( const double a[], size_t n ) {
  double value_of_min = RAND_MAX; 
  long index_of_min = -1; 
  for( size_t i=0; i<n; ++i ) {
    double value = Foo(a[i]); 
    if( value < value_of_min ) {
      value_of_min = value; 
      index_of_min = i;
    }
  } 
  return index_of_min;
}

int main( )  {

  long int n = 1000000;
  double *A = (double *) malloc( n*sizeof(double) );
  for( size_t i=0; i<n; ++i ) A[i] = (double) rand() / RAND_MAX;
  //long indice = SerialMinIndexFoo( A, n );
  long indice = ParallelMinIndexFoo( A, n );
  cout << "Minimo número = " << A[indice] << endl;

}

