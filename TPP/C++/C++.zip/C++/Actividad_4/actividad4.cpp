#include <iostream>
using namespace std;
/* El código desarrollado en la Actividad 3 debe funcionar con el siguiente programa principal. */
/* Si el código está correcto mostrará lo siguiente */
/* a = ( 12, 0 )            */
/* b = ( 0, -11 )           */
/* c = ( 0, 0 )             */
/* d = ( 12, 0 )            */
/* a += b es ( 12, -11 )    */
/* c = ( 12, -22 )          */
/* c = b -a es ( -12, 0 )   */
/* c++ es ( -12, 0 )        */
/* ++c es ( -10, 2 )        */
/* ++a es ( 13, -10 )       */
/* a++ es ( 13, -10 )       */
/* --a es ( 13, -10 )       */
/* a-- es ( 13, -10 )       */
/* b = a-- es ( 0, -11 )    */
/* b = --a es ( 0, -11 )    */
template <typename T>
class NumeroR2 {
private:
 T x, y;

public:
  NumeroR2() : x(0.0), y(0.0) {}

  NumeroR2(T x, T y) : x(x), y(y) {}

  NumeroR2(const NumeroR2 &nr2) : x(nr2.x), y(nr2.y) {}

  friend ostream & operator<<(std::ostream &os, const NumeroR2 &nr2) {
    os << '(' << nr2.x << ", " << nr2.y << ')';
    return os;
  }

  NumeroR2 operator+=(const NumeroR2 &nr) {
      x += nr.x;
      y += nr.y;
      return *this;
    }

  NumeroR2 operator-=(const NumeroR2 &nr) {
      x -= nr.x;
      y -= nr.y;
      return *this;
  }

  NumeroR2 operator+(const NumeroR2 &other) const {
    return NumeroR2(x + other.x, y + other.y);
  }

  NumeroR2 operator-(const NumeroR2 &other) const {
    return NumeroR2(x - other.x, y - other.y);
  }
  
  NumeroR2 operator++() { // versión prefijo
    ++x;
    ++y;
    return *this;
    }

  NumeroR2 operator++(int) { // versión sufijo
    NumeroR2 tmp(*this);
    ++x;
    ++y;
    return tmp;
  }

  NumeroR2 operator--() { // versión prefijo
    --x;
    --y;
    return *this;
    }

  NumeroR2 operator--(int) { // versión sufijo
    NumeroR2 tmp(*this);
    --x;
    --y;
    return tmp;
  }

  NumeroR2 & operator= (const NumeroR2 &rhs) {
    if (this != &rhs) {
      x = rhs.x;
      y = rhs.y;
    }
    return *this;
  }

};

template <typename T>
class Complejo : public NumeroR2<T> {
private:
    T modulo;

public:
    Complejo() : NumeroR2<T>(), modulo(0.0) {}

    Complejo(T x, T y, T modulo) : NumeroR2<T>(x, y), modulo(modulo) {}

    Complejo(const Complejo<T> &c) : NumeroR2<T>(c), modulo(c.modulo) {}

    friend ostream & operator<<(ostream &os, const Complejo<T> &c) {
        os << c.NumeroR2<T>::x << " + " << c.NumeroR2<T>::y << "i";
        return os;
    }

    Complejo<T> operator+=(const Complejo<T> &c) {
        this->NumeroR2<T>::x += c.NumeroR2<T>::x;
        this->NumeroR2<T>::y += c.NumeroR2<T>::y;
        modulo += c.modulo;
        return *this;
    }

    Complejo<T> operator-=(const Complejo<T> &c) {
        this->NumeroR2<T>::x -= c.NumeroR2<T>::x;
        this->NumeroR2<T>::y -= c.NumeroR2<T>::y;
        modulo -= c.modulo;
        return *this;
    }

    Complejo<T> operator+(const Complejo<T> &c) const {
        return Complejo<T>(this->NumeroR2<T>::x + c.NumeroR2<T>::x, this->NumeroR2<T>::y + c.NumeroR2<T>::y, modulo + c.modulo);
    }

    Complejo<T> operator-(const Complejo<T> &c) const {
        return Complejo<T>(this->NumeroR2<T>::x - c.NumeroR2<T>::x, this->NumeroR2<T>::y - c.NumeroR2<T>::y, modulo - c.modulo);
    }

    Complejo<T> operator++() {
        ++this->NumeroR2<T>::x;
        ++this->NumeroR2<T>::y;
        ++modulo;
        return *this;
    }

    Complejo<T> operator++(int) {
        Complejo<T> tmp(*this);
        ++this->NumeroR2<T>::x;
        ++this->NumeroR2<T>::y;
        ++modulo;
        return tmp;
    }

    Complejo<T> operator--() {
        --this->NumeroR2<T>::x;
        --this->NumeroR2<T>::y;
    };

    bool operator<(const Complejo<T> &c) const {
      return modulo < c.modulo;
    }

    bool operator>(const Complejo<T> &c) const {
      return modulo > c.modulo;
    }

    bool operator<=(const Complejo<T> &c) const {
      return modulo <= c.modulo;
    }

    bool operator>=(const Complejo<T> &c) const {
      return modulo >= c.modulo;
    }

    bool operator==(const Complejo<T> &other) const {
        return (this->x == other.x) && (this->y == other.y);
    }

    bool operator!=(const Complejo<T> &other) const {
        return !(*this == other);
    }


};


int main( int argc, char *argv[] ) {
  
  NumeroR2<double> a( 12.0, 0.0 ), b( 0.0, -11.0 ), c, d(a);
  
  cout << "a = " << a << endl;
  cout << "b = " << b << endl;
  cout << "c = " << c << endl;
  cout << "d = " << d << endl;

  a += b;
  cout << "a += b es " << a << endl;

  c = a + b;
  cout << "c = a + b = " << c << endl;

  c = b - a;
  cout << "c = b - a = " << c << endl;

  cout << "c++ es " << c++ << endl;
  cout << "++c es " << ++c << endl;
  cout << "++a es " << ++a << endl;
  cout << "a++ es " << a++ << endl;
  cout << "--a es " << --a << endl;
  cout << "a-- es " << a-- << endl;

  cout << "b = a-- es " << b << endl;
  cout << "b = --a es " << b << endl;

  Complejo<double> x(1.0,3.0), y(-11.0), z;
  z = x + y;
  cout << " z = " << z << endl;

}

