#include <stdlib.h>
#include <iostream>
using namespace std;
/* El código desarrollado en la Actividad 2 debe funcionar con el siguiente programa principal */
/* donde getN es el método que permite obtener la dimensión de la Tabla                        */

/* Si el código está correcto mostrará lo siguiente */
/* Tabla 1: [ 83 86 77 15 93 35 86 92 49 21 ]       */
/* Tabla 2: [ 62 27 90 59 63 ]                      */
/* Tabla 3: [ 62 27 90 59 63 ]                      */
/* Tabla 4: [ 83 86 77 15 93 35 86 92 49 21 ]       */
class Tabla {
private :
  int *elem ; // pointer to the elements
  int n ; // the number of elements
public:
  Tabla() : n(10) {
      elem = new int[10];
    }
    Tabla(int n) : n(n) {
      elem = new int[n];
    }

  inline int getN() const { return n; }

  int& operator [](int i) { return elem[i]; }

  Tabla(const Tabla &t) : n(t.n) {
    elem = new int[n];
    for (int i = 0; i != n; ++i) {
      elem[i] = t.elem[i];
    }
  }

  ~Tabla() { delete[] elem ; }

  Tabla& operator= (const Tabla &t ){
     if (this != &t) {
      delete[] elem;
      n = t.n;
      elem = new int[n];
      for (int i = 0; i != n; ++i) elem[i] = t.elem[i];
    }
    return *this;
  }
 

  friend ostream & operator<< ( ostream&, const Tabla& );

  int* begin() {
  return elem;
  }


  int* end() {
    return elem + n;
  }
};

ostream& operator<<(ostream& outStream, const Tabla& t) {
  outStream << "[ ";
  for (int i = 0; i != t.n; ++i) {
    outStream << t.elem[i] << " ";
  }
  outStream << "]\n";
  return outStream;
}



int main() {

   Tabla t1; 
   Tabla t2(5);

   for( int i=0; i<t1.getN(); i++ ) { 
     t1[i] = rand() % 100;
   }   
   cout << "Tabla 1: " << t1; 
    for( int i=0; i<t2.getN(); i++ ) { 
     t2[i] = rand() % 100;
   }   
   cout << "Tabla 2: " << t2; 
   Tabla t3(t2);
   cout << "Tabla 3: " << t3; 
   Tabla t4(5);
   t4 = t1; 
   cout << "Tabla 4: " << t4;
 
   Tabla t5{5};
   for( auto &e : t5 ) {
    e = rand() % 100;
   }
   cout << "Tabla 5: " << t5;

}

