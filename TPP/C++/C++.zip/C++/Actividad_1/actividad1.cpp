#include <iostream>

void funcion1 (int* a) {
*a =5;
std :: cout << "El resultado de la funcion 1 es:" << a << "\n";
}

void funcion2 (int& b) {
b =5;
std :: cout << "El resultado de la funcion 2 es:" << b << "\n";
}


int main () {
//Parte 1
std :: cout << "Hello , World !\n";
//Parte 2
int e;
int *p=&e;
int &r=e;

e=2;
std :: cout << "El resultado asignando un valor a e es (e):" << e << "\n";
std :: cout << "El resultado asignando un valor a e es (p):" << p << "\n";
std :: cout << "El resultado asignando un valor a e es (r):" << r << "\n\n";

*p=3;
std :: cout << "El resultado asignando un valor a p es (e):" << e << "\n";
std :: cout << "El resultado asignando un valor a p es (p):" << p << "\n";
std :: cout << "El resultado asignando un valor a p es (r):" << r << "\n\n";

r=4;
std :: cout << "El resultado asignando un valor a r es (e):" << e << "\n";
std :: cout << "El resultado asignando un valor a r es (p):" << p << "\n";
std :: cout << "El resultado asignando un valor a r es (r):" << r << "\n\n";
//Parte 3
funcion1(p);
funcion2(r);
}